package prob;
public class Problem3 {
    protected int a=2;
    int b=23;
    public static void main(String[] args) {
        System.out.println("a package in class with three package levels folder , folderL1 , folderL2 ");
    }
}
