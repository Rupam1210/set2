/**
 * InnerProblem4
//  */
// import prob.Problem3;
//  class InnerProblem4 extends Problem3 {
//     void Problem3(){
//         System.out.println(a);
//         // System.out.println(b);
//     }
    
    
// }
// public class Problem4 {
//     public static void main(String[] args) {
//         InnerProblem4 c=new InnerProblem4();
//       // It will throw error if we
      
//     }
// }
